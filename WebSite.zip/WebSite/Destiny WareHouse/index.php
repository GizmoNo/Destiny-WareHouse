<!--Redirects user to Nav Controller apon arival and when a link is clicked-->
<?php

session_start();
    
    if ( isset($_REQUEST["ctr"]) )
    {
        $ControllerName = $_REQUEST['ctr'];
        require_once ("Controller\\".$ControllerName.".php");
    }
else
    require_once "Controller\NavController.php";

?>
