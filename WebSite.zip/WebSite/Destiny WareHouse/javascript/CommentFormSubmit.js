//Java script that is listening for a button click on the SubmitCommentView
$(function() {
    console.log("loaded");
    //Puts Button ID into varible
    var Submit = $("#Send")
        
    //On Click
    $(Submit).click(function(){
        //Puts hidden varible in SubmitCommentView into varible
        var a = $("#UserName");
        //Post information to controller       
        $.post("./?ctr=CommentController",
            {
            //Sets info in form with the corasponding ID and gives it a name for the request
                name: $("#UserName").val(),
                message: $("#message").val(),
                tutorial: $("#tutID").val(),
                cmd:"Submit"
            },
            function(data, status){
            //Data comes back and is displyed in the Div with the following ID
                $("#messageDisplay").html(data);
            }
         );
    });
    
});
          
    