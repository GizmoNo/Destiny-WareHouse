//J Query that moves picture on home screen
$(document).ready(function(){
//ID of div that image is found in.
 var div = $("#animate") 
 //Moves image all the way left and it takes 10 sec to do so.
 $(div).animate({left: "100%"},10000);
      
                      
           
           
        
});