//Listens to text input if incorect custom message will be displayed
var text = document.getElementById("clsname");

text.addEventListener("input", function (event) 
{
      if (text.validity.patternMismatch) 
      {
        text.setCustomValidity("This field must contain two uppercase chacters followed by 2 numbers.");
      } else 
      {
        text.setCustomValidity("");
      }
});


//Listens to text input if incorect custom message will be displayed
var email = document.getElementById("email");

email.addEventListener("input", function (event) 
{
      if (email.validity.patternMismatch) 
      {
        email.setCustomValidity("This is an invalid email.Make sure to include the'@'symbol");
      } else 
      {
        email.setCustomValidity("");
      }
});

//Listens to text input if incorect custom message will be displayed
var tel = document.getElementById("phone");

tel.addEventListener("input", function (event) 
{
      if (tel.validity.patternMismatch) 
      {
        tel.setCustomValidity("Invalid phone number.Phone number must be a new zealand landline or cellphone number");
      } else 
      {
        tel.setCustomValidity("");
      }
});








