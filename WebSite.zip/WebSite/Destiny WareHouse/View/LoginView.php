<!--Login View Of Website-->
<html>

<head>
    <!--Title of Website-->
    <title>
        <?=$this->title?>
    </title>
    <!--Calls CSS style Sheets-->
    <?php
    

                                require_once("View/SubViews/StyleSheetsView.php");
//If a login or register is unsucsessful this will set a varible so it shows an error message. An error message is not shown if Session varible = 0
    switch($_SESSION["True"])
    {
        case "1":   
            $Error = "UserName already exists please choose another username";
            $_SESSION["True"] = "0";
            break;
        case "2":
            $Error = "UserName or password is incorect";
            $_SESSION["True"] = "0";
            break;
        default:
            $Error = ""; 
    }
           ?>
    
    


</head>
<!--Sets Back Ground Image-->

<body class="BackGroundImage" background="Images/Website Background.jpg">




    <div class="container-fluid">

        <!--Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h1 class="SiteHeading">
                    <?=$this->title?>
                </h1>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Navigation Section-->
        <div class="row">
            <!--Calls Navigation Bar from another View-->
            <div class="col-md-12">
                <?php

                                        require_once("View/SubViews/NavView.php")

                                        ?>

            </div>
        </div>
        <!--Secondary Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h2 class="SiteSubHeading">
                    Login
                </h2>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Login Form-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <!--Area to show error message if needed-->
                <label class="ErrorText"> <?=$Error?></label>
                <form action="./?ctr=LoginController" method="post">
                    <div class="imgcontainer">
                        <img src="Images/PlaceHolder Avatar.png" alt="Avatar" class="avatar">
                    </div>
                    <!--UserName Field -->
                    <div class="container">
                        <label for="uname"><b>Username</b></label>
                        <input type="text" placeholder="Enter Username" name="uname" id = "userName" required>
                        <!--Password field -->
                        <label for="psw"><b>Password</b></label>
                        <input type="text" placeholder="Enter Password" name="psw" id = "passWord" required>
                        <!--Login Button -->
                        <button type="submit" name="command" value="Login">Login</button>
                        <!--Register Button -->
                        <button type="submit" name="command" value="Register">Register</button>
                        
                    </div>

                    
                </form>

            </div>
            <div class="col-md-3">
            </div>
        </div>

        <!--Footer-->
        <div class="row">
            <div class="col-md-12 FooterBackground">
                <br>
                <br>
                <br>
                <br>
            </div>
        </div>
    </div>



</body>

</html>
