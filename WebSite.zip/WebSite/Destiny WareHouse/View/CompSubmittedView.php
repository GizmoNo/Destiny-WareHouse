<!--View After Comp Form Has Been Submitted-->

<html>

<head>
    <!--Title of Website-->
    <title>
        <?=$this->title?>
    </title>
    <!--Calls CSS style Sheets-->
    <?php

        require_once("View/SubViews/StyleSheetsView.php");
        require_once ("Model/CompModel.php");
            //Create new compModel        
            $compModelUserInfo = new CompModel();
                //Gets comp info submitted by user on previous view Passes in user email saved as a global varible    
                $userCompInfo = $compModelUserInfo->getUserCompInfo($_SESSION['userEmail']);
                        //Set varibles with data from database
                        $ClassName = $userCompInfo["ClassRoomName"];
                        $SchoolName = $userCompInfo["SchoolName"];
                        $Email = $userCompInfo["PupilEmail"];
                        $PhoneNo = $userCompInfo["PhoneNumber"];
                        $QuestionID = $userCompInfo["QuestionAnswerQuestionQuestionID"];
                        $AnswerID = $userCompInfo["QuestionAnswerAnswerAnswerID"];
        
            //Create new compModel. Must create new model as only one SQL statement can be run per model.
            //Get error if you try run two SQL statements on the same model.
            $compModelQuestionInfo = new CompModel();
                //sends IDs to function to get question and answer user chose
                $userCompAnswer = $compModelQuestionInfo->getUserCompAnswer($QuestionID,$AnswerID);
                        //puts the question and answer into varible
                        $Question = $userCompAnswer["question"];
                        $Answer = $userCompAnswer["answer"];
        
        
        
        
    ?>

</head>
<!--Sets Back Ground Image-->
<body class="BackGroundImage" background="Images/Website Background.jpg">

    <div class="container-fluid">

        <!--Heading Section-->
        <div class="row">
            
            <div class="col-md-3">
            </div>
            
            <div class="col-md-6">
                
                <h1 class="SiteHeading">
                    <?=$this->title?>
                </h1>
                
            </div>
            
            <div class="col-md-3">
            </div>
            
        </div>
        
        <!--Navigation Section-->
        <div class="row">
            <!--Calls Navigation Bar from another View-->
            <div class="col-md-12 mypaddingfix">
                
                <?php

                    require_once("View/SubViews/NavView.php")

                ?>
                
            </div>
            
        </div>
        <!--Secondary Heading Section-->
        <div class="row">
            
            <div class="col-md-3">
            </div>
            
            <div class="col-md-6">
                
                <h2 class="SiteSubHeading">
                    Your Entry Has Been Submitted Your Details Are As Follows.
                </h2>
                
            </div>
            
            <div class="col-md-3">
            </div>
            
        </div>
        
        <div class="row">
            
            <div class="col-md-2">
            </div>
            
            <div class="col-md-8">
                  
               <!--Create heading for each set of data and displays it on screen as the varible-->
                <h3 class="SiteCompHeading">Class Name</h3>
                <h4 class="SiteCompText"><?=$ClassName?></h4>
                <br>
                <br>
                <h3 class="SiteCompHeading">School Name</h3>
                <h4 class="SiteCompText"><?=$SchoolName?></h4>
                <br>
                <br>
                <h3 class="SiteCompHeading">Your Email</h3>
                <h4 class="SiteCompText"><?=$Email?></h4>
                <br>
                <br>
                <h3 class="SiteCompHeading">Phone Number</h3>
                <h4 class="SiteCompText"><?=$PhoneNo?></h4>
                <br>
                <br>
                <h3 class="SiteCompHeading">Question Answered</h3>
                <h4 class="SiteCompText"><?=$Question?></h4>
                <br>
                <br>
                <h3 class="SiteCompHeading">Your Answer</h3>
                <h4 class="SiteCompText"><?=$Answer?></h4>
                
            </div>
            
            <div class="col-md-2">
            </div>
            
        </div>
        
        <div class="row">
            <!-- Footer Section -->
            <div class="col-md-12 FooterBackground mypaddingfix">
                <br>
                <br>
                <br>
                <br>
            </div>
        </div>
    </div>


</body>

</html>