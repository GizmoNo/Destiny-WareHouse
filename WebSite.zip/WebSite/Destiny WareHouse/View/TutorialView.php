<!--Tutorial Page Is where all tutorials are displayed from any catagory and links the user to sub catagories-->
<html>

<head>
    <!--Title of Website-->
    <title>
        <?=$this->title?>
    </title>
    <!--Calls CSS style Sheets-->
    <?php

                                require_once("View/SubViews/StyleSheetsView.php")

                          ?>

</head>
<!--Sets Back Ground Image-->

<body class="BackGroundImage" background="Images/Website Background.jpg">




    <div class="container-fluid">

        <!--Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h1 class="SiteHeading">
                    <?=$this->title?>
                </h1>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Navigation Section-->
        <div class="row">
            <!--Calls Navigation Bar from another View-->
            <div class="col-md-12 mypaddingfix">
                <?php

                                        require_once("View/SubViews/NavView.php")

                                        ?>
            </div>
        </div>
        <!--Secondary Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h2 class="SiteSubHeading">
                    Tutorial Page
                </h2>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Image Links Section-->
        <div class="row">
            <!--Link Takes User To Strike Tutorial Page-->
            <div class="col-md-6">
                <a href="?ctr=ImageNavController&cmd=Strikes"><img class="TempImage" src="Images/Strikes.png" alt="" />
                </a>
            </div>
            <!--Link Takes User To Raid Tutorial Page-->
            <div class="col-md-6">
                <a href="?ctr=ImageNavController&cmd=Raids"><img class="TempImage" src="Images/Raids.jpg" alt="" />
                </a>
            </div>
        </div>
        <!--Tutorial Links Section-->
        <div class="row ">
            <div class="col-md-3">
            </div>
            <div class="col-md-6 ">
                <p class="TutorialLinks">
                    <!--Links User To Strike Tutorial-->
                    <a href="?ctr=TextNavController&cmd=Strike">The Inverted Spire Strike Guide</a>
                    <br>
                    <br>
                    <br>
                    <!--Links User To Strike Tutorial2-->
                    <a href="?ctr=TextNavController&cmd=Strike2">The Arms Dealer Strike Guide</a>
                    <br>
                    <br>
                    <br>
                    <!--Links User To Raid Tutorial-->
                    <a href="?ctr=TextNavController&cmd=Raid">Lethiathan Raid Guide</a>

                </p>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Footer-->
        <div class="row FooterBackground">
            <div class="col-md-12">
                <br>
                <br>
                <br>
                <br>

            </div>
        </div>
    </div>




</body>

</html>
