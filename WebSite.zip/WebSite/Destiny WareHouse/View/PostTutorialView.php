<!--Post Tutorial View-->
<!--Most likely will not use for final hand in as I have over 5 pages already-->
<html>

<head>
    <!--Title of Website-->
    <title>
        <?=$this->title?>
    </title>
    <!--Calls CSS style Sheets-->
    <?php

                                require_once("View/SubViews/StyleSheetsView.php")

                          ?>

</head>
<!--Sets Back Ground Image-->

<body class="BackGroundImage" background="Images/Website Background.jpg">




    <div class="container-fluid">

        <!--Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h1 class="SiteHeading">
                    <?=$this->title?>
                </h1>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Navigation Section-->
        <div class="row">
            <!--Calls Navigation Bar from another View-->
            <div class="col-md-12 mypaddingfix">
                <?php

                                        require_once("View/SubViews/NavView.php")

                                        ?>
            </div>
        </div>
        <!--Secondary Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h2 class="SiteSubHeading">
                    Post Tutorial Coming Soon
                </h2>
            </div>
            <div class="col-md-3">
            </div>
        </div>
    </div>



</body>

</html>
