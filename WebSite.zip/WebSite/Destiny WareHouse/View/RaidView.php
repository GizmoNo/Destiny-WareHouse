<!--This page is the raid specific catagory page and only conatins raid tutorial elements-->
<html>

<head>
    <!--Title of Website-->
    <title>
        <?=$this->title?>
    </title>
    <!--Calls CSS style Sheets-->
    <?php

                                require_once("View/SubViews/StyleSheetsView.php")

                          ?>

</head>
<!--Sets Back Ground Image-->

<body class="BackGroundImage" background="Images/Website Background.jpg">




    <div class="container-fluid">

        <!--Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h1 class="SiteHeading">
                    <?=$this->title?>
                </h1>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Navication Section-->
        <div class="row">
            <!--Calls Navigation Bar from another View-->
            <div class="col-md-12">
                <?php

                                        require_once("View/SubViews/NavView.php")

                                        ?>
            </div>
        </div>
        <!--Secondary Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h2 class="SiteSubHeading">
                    Raid Tutorial Page
                </h2>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!-- Carousel Section -->
        <div class="row">
            <div class="col-md-12 mypaddingfix">
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img class="d-block w-100" src="Images/DestinyRaidLethiathan.jpg" alt="First slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="Images/DestinyRaidLethiathanPart2.jpg" alt="Second slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="Images/DestinyRaidEaterOfWorlds.jpg" alt="Third slide">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>


                <br>
            </div>
        </div>
        <!--Raid Tututorial Links-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <!--Links User To Raid Tutorial-->
                <p class="TutorialLinks">
                    <a href="?ctr=TextNavController&cmd=Raid">Lethiathan Raid Guide</a>
                    <br>
                    <br>

                </p>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Footer-->
        <div class="row">
            <div class="col-md-12 FooterBackground">
                <br>
                <br>
                <br>
                <br>
            </div>
        </div>
    </div>



</body>

</html>
