<?php 
  require_once("Model/CommentModel.php");
  
  
  $ComtModel = new CommentModel();

  //Gets all messages for a tutorial
  $ComtModel->SetUpMessages($_SESSION['TutorialPage']);

  // This is a title 
  ?>
<h4 class="SiteSubHeading">Messages</h4>
<?php

  // Show all messages - loop while there is a NextMessage

  while( $row = $ComtModel->NextMessage()){
      
      ?>
<!--Displays Messages in this format with a class that makes text white.-->
<body>
    <p class="pContent">
        <?=$row['UserName']." said :  ".$row['Comment']?> <br>
    </p>
</body>

     <?php
      
  }
  
  
  $ComtModel->FreeMessages();
 
?>
