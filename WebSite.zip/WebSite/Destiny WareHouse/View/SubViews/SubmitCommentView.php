<!--This is the comment view-->
<html>

<head>
    
    <title>
        <?=$this->title?>
    </title> 
    
    <?php
    

                                require_once("View/SubViews/StyleSheetsView.php");
        ?>
    
</head>

<body>
    <div class="row">
        <div class = "col-md-12">
<h4 class = "SiteCompHeading">Comment Section</h4>

        </div>
    </div>
    <div class="row">
    <div class = "col-md-12" align="center">
        <!--Form for user to type a comment and post it-->
        <form id="Comment" name="CommentField" class="CommentBox" >
            <input name = "name" type = "hidden" id="UserName" value="<?=$_SESSION['UserName']?>">
            <input name = "tutorialID" type = "hidden" id="tutID" value="<?=$_SESSION['TutorialPage']?>">
                <textarea name="message" id="message" rows="10" cols="100">






                </textarea>
            <br>
            <!--Submits Comment-->
                <button type="button" id="Send" value="Send" name="cmd">Submit</button>

        </form>
    </div>
</div>
    <div class="row">
        <div class = "col-md-12">
            <div id="messageDisplay" class="scroll">
                <!--View that shows and is used to update comments when another is submited-->
                <?php
    

                                require_once("View/SubViews/CommentView.php");
        ?>
            </div>

        </div>
    </div>
    
    
    
    
    
    <!--Scripts Used on view-->
            <script src = "javascript/jquery-3.3.1.min.js"></script> 
            <script src = "javascript/CommentFormSubmit.js"></script> 

    </body>






</html>