<!--Navigation Bar For All Site Pages-->
<div class="nav">
    

    

    <ul>
        <li><a href="?cmd=Home">Home</a></li>
        <li><a href="?cmd=Tutorials">Tutorials</a></li>
        <li><a href="?cmd=ContactUs">Contact Us</a></li>
        <li> <a href="?cmd=Post Tutorial">Post Tutorial</a></li>
        
<!-- If loged in the log out button will replace the login button -->
<!-- If user not loged in then login button will be shown -->
<?php 
        if($_SESSION['UserName'] == null)
        {
?>
            <li><a href="?cmd=Login">Login</a></li>
<?php
        }
        else
        {
?>
           <li><a href="?cmd=LogOut">Log Out</a></li> 
<?php 
        }
?>
        
            
            
            

    </ul>

</div>
