<!--CompView Form View-->
<html>

<head>
<!--Title of Website-->
    <title>
        <?=$this->title?>
    </title>
<!--Calls CSS style Sheets-->
    <?php

        require_once("View/SubViews/StyleSheetsView.php");
        require_once ("Model/CompModel.php");
        #Creates new compModel
        $compModel = new CompModel();
            #When Page Is Loaded This Runs Getting An Array a Question and Answers
            $questionRow = $compModel->getQuestion();

                #Putting all the array varibles into there own public varibles to be used bellow
                $question = $questionRow["question"];
                $questionID = $questionRow["QuestionID"];
                $Answer1 = $questionRow["answer"];
                $Answer1ID = $questionRow["answerID"];

                $questionRow = $compModel->nextAnswer();
                $Answer2 = $questionRow["answer"];
                $Answer2ID = $questionRow["answerID"]; 
        
                $questionRow = $compModel->nextAnswer();
                $Answer3 = $questionRow["answer"];
                $Answer3ID = $questionRow["answerID"];
        //If session varible = 1 then the school does not exist so an error message will show for the user        
        if($_SESSION["True"] == "1")
        {
            $Error = "This school does not exist. Please enter a local NewZealand school. Please make sure to use it's full name E.g. St Mary's School, Nelson High School.....";
            $_SESSION["True"] = "0";
        }
        else
        {
            $Error = "";
        }

     ?>
    
    
    
</head>
<!--BackGround Image-->
<body class="BackGroundImage" background="Images/Website Background.jpg">



    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">

            </div>
            
            <div class="col-md-6">
                <!--Site Heading-->
                <h1 class="SiteHeading">
                    <?=$this->title?>
                </h1>
            </div>
            
            <div class="col-md-3">
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12">
            </div>
            
        </div>
        
        <div class="row">
            <div class="col-md-12">
                <!--Navigation Bar-->
                <?php

                    require_once("View/SubViews/NavView.php")

                ?>
                
            </div>
        </div>
        
        <div class="row">
            <!--Compitition Form-->
            <div class="col-md-12">


                <form action="./?ctr=CompController" method="post">

                    <h2 class="SiteSubHeading">Enter Your Details Here</h2>

                            <p class="CompHeading">Required fields are followed by <strong><abbr title="required">*</abbr></strong>.</p>

                    <div>
                            <!--Text Box For ClassRoom Name-->
                            <h3 class="CompHeading">Classroom Name<strong><abbr title="required">*</abbr></strong></h3>
                        <!--Regular expression that only allows 2 uppercase letters followed by 2 numbers.-->
                            <input type="text" id="clsname" name="classroom_name" value="" required pattern="^[A-Z].*[A-Z].*[0-9].*[0-9]$">
                    </div>
                    
                    <div>
                            <!--Text Box For School Name-->
                            <h3 class="CompHeading">School Name<strong><abbr title="required">*</abbr></strong></h3>
                        <!--No regular expression used for the school name. School name is check by a database query as there were around 2500 to check this was the most viable option.-->
                        <h4 class="ErrorText"> <?=$Error?></h4>
                            <input type="text" id="schname" name="school_name" value="" >
                    </div>
                    
                    <div>
                            <!--Text Box For Pupil Email-->
                            <h3 class="CompHeading">Email<strong><abbr title="required">*</abbr></strong></h3>
                        <!--Regular expression was not created my me but was found on a website that provided a good email expression that works well.-->
                            <input class="TextFields" type="email" id="email" name="pupil_email" value="" required pattern="^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$">
                    </div>
                    
                    <div>
                            <!--Text Box For Pupil Phone Number-->
                            <!--Regular expression used to check all posible phone number combos so that the number inputted will have to be a valid national phone number-->
                            <h3 class="CompHeading">Phone Number<strong><abbr title="required">*</abbr></strong></h3>
                            <input class="TextFields" type="tel" id="phone" name="pupil_phone" value="" required pattern="^((304)|(440)|(447)|(448)|(449)|(314)|(302)|(303)|(307)|(308)|(908)|(412)|(413)|(415)|(418)|(419)|(2654)|(3941)|(520)|(5547)|(570)|(572)|(573)|(574)|(575)|(577)|(578)|(579)|(6998)|(7451)|(921)|(9273)|(9284)|(9293)|(9720)|(9721)|(9722)|(9723)|(9724)|(984)|(9868)|(9869)|(32)|(33)|(34)|(35)|(36)|(37)|(38)|(94)|(98)|(445)|(315)|(317)|(318)|(319)|(425)|(453)|(454)|(455)|(456)|(457)|(464)|(466)|(467)|(468)|(469)|(470)|(471)|(472)|(474)|(476)|(477)|(478)|(479)|(481)|(482)|(483)|(484)|(486)|(487)|(488)|(489)|(552)|(929)|(949)|(950)|(951)|(955)|(974)|(206)|(685)|(201)|(202)|(203)|(204)|(205)|(207)|(208)|(209)|(738)|(762)|(768)|(769)|(755)|(21)|(485)|(417)|(538)|(539)|(522)|(542)|(543)|(544)|(545)|(546)|(547)|(548)|(571)|(576)|(434)|(437)|(439)|(463)|(465)|(731)|(409)|(428)|(441)|(442)|(450)|(451)|(444)|(310)|(311)|(312)|(313)|(732)|(234)|(446)|(612)|(614)|(615)|(683)|(684)|(686)|(687)|(688)|(689)|(305)|(443)|(782)|(788)|(789)|(23)|(38)|(46)|(47)|(49)|(52)|(56)|(57)|(58)|(61)|(80)|(97)|(93)|(29)|(90)|(47)|(46)|(3220)|(3221)|(3222)|(3293)|(374)|(272)|(273)|(274)|(278)|(833)|(835)|(837)|(839)|(843)|(844)|(845)|(877)|(875)|(876)|(878)|(879)|(888)|(862)|(863)|(867)|(868)|(756)|(362)|(363)|(364)|(366)|(367)|(368)|(3219)|(3228)|(3229)|(327)|(370)|(372)|(377)|(378)|(379)|(929)|(946)|(75)|(751)|(752)|(753)|(754)|(755)|(385)|(375)|(376)|(323)|(324)|(325)|(326)|(328)|(329)|(35)|(929)|(951)|(762)|(763)|(764)|(765)|(304)|(306)|(307)|(308)|(9468)|(382)|(388)|(387)|(213)|(342)|(343)|(344)|(345)|(346)|(347)|(348)|(349)|(211)|(280)|(823)|(824)|(825)|(827)|(829)|(83)|(84)|(85)|(957)|(826)|(828)|(880)|(888)|(884)|(887)|(889)|(315)|(325)|(873)|(862)|(282)|(33)|(34)|(36)|(46)|(89)|(3339)|(37)|(38)|(281)|(54)|(55)|(56)|(57)|(92)|(77)|(870)|(871)|(872)|(876)|(877)|(878)|(864)|(866)|(867)|(868)|(869)|(882)|(883)|(885)|(886)|(863)|(281)|(307)|(308)|(323)|(922)|(865)|(30)|(33)|(35)|(37)|(360)|(361)|(376)|(378)|(372)|(520)|(522)|(523)|(524)|(529)|(502)|(521)|(528)|(525)|(526)|(571)|(579)|(580)|(527)|(573)|(574)|(528)|(620)|(621)|(629)|(623)|(630)|(631)|(638)|(639)|(624)|(625)|(626)|(627)|(622)|(633)|(634)|(636)|(815)|(845)|(820)|(828)|(829)|(846)|(849)|(411)|(412)|(416)|(810)|(811)|(812)|(814)|(811)|(816)|(817)|(813)|(818)|(825)|(826)|(827)|(831)|(832)|(833)|(834)|(839)|(835)|(836)|(837)|(838)|(839)|(261)|(262)|(263)|(263)|(266)|(267)|(268)|(269)|(271)|(272)|(273)|(274)|(277)|(278)|(279)|(255)|(256)|(275)|(636)|(259)|(270)|(276)|(277)|(278)|(279)|(292)|(293)|(294)|(296)|(297)|(298)|(299)|(410)|(413)|(414)|(415)|(418)|(419)|(480)|(481)|(440)|(442)|(443)|(444)|(445)|(446)|(473)|(477)|(478)|(479)|(480)|(482)|(483)|(486)|(488)|(489)|(530)|(273)|(274)|(534)|(535)|(536)|(537)|(538)|(536)|(527)|(570)|(573)|(574)|(575)|(570)|(576)|(577)|(21)|(55)|(91)|(92)|(94)|(95)|(96)|(97)|(980)|(439)|(9015)|(429)|(9049)|(420)|(9040)|(421)|(424)|(426)|(427)|(428)|(9044)|(4310)|(4311)|(4316)|(4317)|(4318)|(9019)|(401)|(405)|(407)|(9017)|(408)|(402)|(403)|(404)|(9012)|(230)|(234)|(235)|(236)|(237)|(238)|(239)|(422)|(423)|(425)|(4312)|(4314)|(4315)|(902)|(430)|(432)|(433)|(434)|(435)|(436)|(437)|(438)|(459)|(470)|(983)|(986)|(021)|(027)|(022)|(0204)|(0201)|(0202)|(0203)|(0205)|(0206)|(0207)|(0208)|(0209)|(026)|(0280)|(028)|(0284)|(029))([0-9]{4}|[0-9]{3}|[0-9]{5}|[0-9]{8})$">
                    

                    </div>

                    <fieldset>
                        
                        <legend class="CompHeading" value="">
                            <!--Question Pulled Out Of DataBase Randomly-->
                            <?= $question ?> <strong><abbr title="required">*</abbr></strong>
                            
                        </legend>
                        <!--Hidden varible for QuestionID for when sent to database-->
                        <input class="" type="hidden" name="question_ID" value="<?= $questionID ?>">

                        <p>
                            <!--Radio Button With Question Answer Will send AnswerID to database if selected-->
                            <input type="radio" name="question" checked id="question_1" value="<?= $Answer1ID ?>">
                            <!--Answer for quesion pulled out of database-->
                            <label class="pContent" for="question_1">
                            <?= $Answer1 ?></label>
                            
                        </p>
                        <p>
                            <!--Radio Button With Question Answer Will send AnswerID to database if selected-->      
                            <input type="radio" name="question" id="question_2" value="<?= $Answer2ID ?>">
                            <!--Answer for quesion pulled out of database-->
                            <label class="pContent" for="question_2">
                            <?= $Answer2 ?></label>
                            
                        </p>
                        
                        <p>
                            <!--Radio Button With Question Answer Will send AnswerID to database if selected-->
                            <input type="radio" name="question" id="question_3" value="<?= $Answer3ID ?>">
                            <!--Answer for quesion pulled out of database-->
                            <label class="pContent" for="question_3">
                            <?= $Answer3 ?></label>
                            
                        </p>
                        
                    </fieldset>

                    <div class="button">
                            <!--Click to submit form will send name and value to compcontroller-->
                            <button type="submit" name="command" value="CompSubmission">Enter</button>

                    </div>

                </form>

            </div>
        </div>
    </div>


    <script type="text/javascript" src="javascript/compscript.js"></script>
</body>
    

</html>
