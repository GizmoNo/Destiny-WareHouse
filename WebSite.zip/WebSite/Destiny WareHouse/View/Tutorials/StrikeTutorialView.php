<!--Strike Tutorial Page-->
<html>

<head>
    <!--Title of Website-->
    <title>
        <?=$this->title?>
    </title>
    <!--Calls CSS style Sheets-->
    <?php

                                require_once("View/SubViews/StyleSheetsView.php")

                          ?>

</head>
<!--Sets Back Ground Image-->

<body class="BackGroundImage" background="Images/Website Background.jpg">




    <div class="container-fluid">

        <!--Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h1 class="SiteHeading">
                    <?=$this->title?>
                </h1>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Navigation Section-->
        <div class="row">
            <!--Calls Navigation Bar from another View-->
            <div class="col-md-12">
                <?php

                                        require_once("View/SubViews/NavView.php")

                                        ?>
            </div>
        </div>
        <!--Secondary Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h2 class=SiteSubHeading>
                    Inverted Spire Strike Tutorial
                </h2>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    When you first spawn in follow the way point until you reach a bunch of enemys. Kill all of these enemys and then use your ghost on the light piller. After a while a few platforms will spawn and you can make your way accross. Keep following the pathway to the way point you can ignore the enemys if you want for a speed run they do not have to be killed.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/InvertedSpireStrikeImages/Part 1.png" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Once you have reached the area with the light barrier you must kill enemys until a mini boss apares. Once he has been killed you can continue on. These is no special statagy to this just kill enemys and stay alive.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/InvertedSpireStrikeImages/Part 2.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Keep following the way point until you come accross a big area with cabal. There will be 2 mini bosses you must kill to proceed. Once they have been killed you are able to activate a leave that will be marked with a way point. Follow the path to the next area and drop down.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/InvertedSpireStrikeImages/Part 3.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    When you drop down you will be greated by a bunch of enemys. You must activte a leaver that is marked to start the process of the drill. You then must just stay alive until the drill stops moving. When it is ready take the cannon to the next area and follow path until you rach another drill.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/InvertedSpireStrikeImages/Part 4.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    This next area you must make your way though while avoiding the drill that is running around. If you get hit by this drill you will more than likely die. This is a short section if skilled enough you can use your sparrow and drive past all the ememys or just run past them all. Once though follow the path and drop down.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/InvertedSpireStrikeImages/Part 5.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Once you drop down you are in the first phase of the boss fight. Once it spawns you must do enough dammage to him for the platform you are standing on disappears. You will also have other enemys to deal with make sure to kill these first as if you get overwelmed you will die. Once the platform disappears fall to the next stage.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/InvertedSpireStrikeImages/Part 6.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    This nect phase will be a little different. Every now and then the boss will strike the ground and light the platform on fire. You must jumo and stay in the air or stand on one of the raised platforms so you don't get hurt. Continue this while killing enemys until the platforms disappears again and fall to the next phase.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/InvertedSpireStrikeImages/Part 7.png" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    This is the last phase. Here the boss will stay in the outer area of the boss area if you stand here you will be dammaged youself. You must do enought dammage to him to being him to the middle platform. As this is going you must make sure to kill other enemys otherwise you will be overwelmed. Keep this process up until you defeat the boss and claim your loot.
                    <br>
                    <br>
                    Contradulations you have completed the strike




                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/InvertedSpireStrikeImages/Part 8.png" alt="" />
            </div>
        </div>
        <!--Comment Section-->
        <div class="row">
            <div class="col-md-12">
    <!--If user is not loged in then they will be unable to see the comment section-->
                <?php            
    if($_SESSION['UserName'] == null)
    {
    ?>
           <h4 class="SiteSubHeading">You Must Login To See Comments</h4>     
    <?php           
                
    }
    else
    {
       require_once("View/SubViews/SubmitCommentView.php");     
    }
    ?>

            </div>
        </div>
        <!--Footer-->
        <div class="row">
            <div class="col-md-12 FooterBackground">
                <br>
                <br>
                <br>
                <br>
            </div>
        </div>
    </div>



</body>

</html>
