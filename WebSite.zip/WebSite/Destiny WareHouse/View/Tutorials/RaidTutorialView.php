<!--Raid Tutorial Page-->
<html>

<head>
    <!--Title of Website-->
    <title>
        <?=$this->title?>
    </title>

    <!--Calls CSS style Sheets-->
    <?php

                                require_once("View/SubViews/StyleSheetsView.php")

                          ?>

</head>

<!--Sets Back Ground Image-->

<body class="BackGroundImage" background="Images/Website Background.jpg">




    <div class="container-fluid">

        <!--Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h1 class="SiteHeading">
                    <?=$this->title?>
                </h1>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Navigation Section-->
        <div class="row">
            <div class="col-md-12">
                <!--Calls Navigation Bar from another View-->
                <?php

                                        require_once("View/SubViews/NavView.php")

                                        ?>
            </div>
        </div>
        <!--Secondary Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h2 class=SiteSubHeading>
                    Lethiathan Raid Tutorial
                </h2>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    When you first load into the raid follow the pathway on front of you and head up the stairs. You do not need to attack these enemys you see as they will just stand idle unless you attack them. Once at the top of the stairs head inside until you reach a big open room.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Step 1.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    You will find yourself in a big room this is basicly the "Hub" of this raid as you will end up coming back to this location several times. As you look around the room you should find a plate with a glowing symbol there are four of these types of plates around the room The plate that is lit up is where you need to go.




                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Step 2.jpg" alt="" />
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    There are four types of symbols. The dog, The sun, The axes and the cup. these symbols are used many times though out the raid. In this main room each symbol represents four different rooms. The dog takes youto the gardens , The cup takes you do the royal baths, the axes take you to the gauntlet and the sun takes you to the boss. The sun is always the last plate that will light up and the rest is always random every week. This means that the raid will not be the same every given week.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Step 3.jpg" alt="" />
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Once you step onto the plate that is lit up enemys will start to spawn. Four people should stay at the plate to protect it while one goes out to get the flags. This section is basicly capture the flag. The two that go out will be able to see what flag as spawned. Once there you will have to kill a mini boss to be able to pick up the flag. Once this mini boss has been killed you can pick up the flag. You then need to run this flag back to the plate your team mates are guarding when you get there place the flag down and another one will spawn. Do this until you get all 3 flags.
                    <br>
                    For team guarding the plate you will have to kill these specials knights that can take flags back if not killed. But sometime these knights have unbreakable shields. This is because there will be a cyon near by you must find it and kill it to drop this shield to be able to kill the knight. If a flag is taken the away team will have to go get it again.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6"> 
                <img class="TempImage" src="Images/RaidTutorialImages/Step 4.png" alt="" />
            </div>
        </div>
        <br>
        <div class="row">
            <div class = "col-md-12">
                <h3 class=SiteSubHeading>Royal Pools</h3>
            </div>
        </div>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    When you first enter this area you will find four plates around the room and one in the middle with a black orb. This black orb once grabed starts the encounter. You start with one player on each plate and 2 people in the middle. Once you are ready to start each player in the middle must grab an orb and head to one of the plates. Once peron should go left and one go right.




                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Pools Step 1.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Once The player from the middle comes over to a plate that person from the middle gets on the plate and the other player runs into the middle to get another black orb. Then this player will go to the other plate on there side of the room and take over the that players plate. Then that player goes to the middle and goes to the first players plate. This continues of both sides  in a loop until each chain has been brought down. If you get off the plate the chian will start to reset so try stay on the plate at all times while killing mobs. Once all chains are down everyone will hear a bell sound eveyone need to go to the middle room.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Pools Step 2.png" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Once in the middle room two people should keep killing mobs while everyone else shoots lamps. There will be three sets of lambs brought down from the celling. You must destory all these lamps to finish this phase. You also must stand on the plate in the middle of the room so you can do dammage to the lamps. If you are unable to destory all lamps then reset and do the same  rotation again as explained above until you destory them all. Once all destoryed a chest will apare and you can head back to the "Hub area where you must open another door using the capture the flag game again.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Pools Step 3.jpg" alt="" />
            </div>
        </div>
        <br>
        <div class="row">
            <div class = "col-md-12">
                <h3 class=SiteSubHeading>Gardens</h3>
            </div>
        </div>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    When you first enter the garden you will see a indoor forest and a big statue at the other end of the room. When you are ready to start you need to head to this statue and pick up the gems you can see there to start the encounter. But before that you will need to kill the enemys currently in the room. After that I suggest that you look around the room to find the spores. There are 8 spores in the room 3 on the left 3 on the right and 2 in the middle. Find these spores and alocate one to each of the team members.




                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Gardens Step 1.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Two team mates will have to stay up top holding the gems. These gems will be used to give the team down below stacks of spores when they are close to one. When the team gets to one of the spores you must shoot it with the gem.  Note : You must alsobe standing in a piller of light to be able to shoot the gem.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Gardens Step 2.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    When the 2 team mates pick up the gems the rest of the team must drop down and pick up one of these balls shown in the screen shot. With these balls in hand everyone must sneak around to each of the spores the the room while aviding the dogs patrolling the area. Your mission is to get as many stack of spores you can the more you have the more dammage you can deal to the dogs. If you are spoted the dammage phace will start you want to have at least 32 stacks before you start dammage phase more would be very good. If you have below 32 when the dammage phase starts it will be worth starting again.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Gardens Step 3.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    For the players on top when the team is near one of these spores you are to shoot the spores with the gem as shown in the screen shot. When the dammage phase starts you can jump down and help out with killing the dogs.




                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Gardens Step 4.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    During the dammage phase you have a limited amount of time to do dammage. The dogs will start to howl and you must make it into the safe room before the end of this otherwise you will be killed. The best way to handle dammage is to get each dog down to about half at least and head back to the safe room don't kill any dogs in the first phase otherwise it will make it harder to kill the dogs in the next phase. You do repete this process one more time and once all the dogs are dead you have completed the gardens. A chest will spawn next to the statue and you can head back to the hub area to begin the capture the flag phase again.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Gardens Step 5.png" alt="" />
            </div>
        </div>
        <br>
        <div class="row">
            <div class = "col-md-12">
                <h3 class=SiteSubHeading>Gauntet</h3>
            </div>
        </div>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Once you have gone up the elevator you will fine yourself in the gauntet room. Looking around you will see 4 raised platforms and symbols on the walls. To start the encounter you must lower these platforms by standing on them.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Gauntlet Step 1.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Each platform has a symbol to symbolize each gate within the gauntet. you will have to asign 2 runners and have one person on each plate. When you start the encounter you will have to kill mob enemys until 2 black orbs spawn. The runners must grab these to enter the gauntet. 




                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Gauntlet Step 2.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Once inside the gauntet you will be tasked in running around it while having to open gates to proceed. You need to look at the symbol on that gate and the ring that is lit up read. This is what you must call for the people outside. For example, Dog Bottom. This means that there was a dog symbol and the red ring was on the bottom row. If the people on the outside did there job corectly the door will flash green and you must grab the black orb that spawns there. Continue this until you get out the the gauntet

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Gauntlet Step 3.png" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    
                    People on the outside will see sets of arrows in fount of them. each person will have to be asigned to keep an eye out for 2 different symbols. when for example a person calls out dog bottom you must shoot the arrows there the dog symbol is but only shoot the arrows theother plaer did not call out. For example if he calls bottom you will shoot the top and middle arrow. Each arrow needs to be shot at the same time and that's why people will have to keep an eye on 2 different symbols.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Gauntlet Step 4.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    After you shoot arrows a cyon will spawn you must quickly jump off your platform and kill this guy. He can only be killed will a melee attack so you will have to run up to him and then run back to your platform and contine opening gates. 



                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Gauntlet Step 5.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Once out of the gauntet you then must run the orbs you carry into the centure room and dunk them into the middle. Once this is done next next phase will start where you will do the same thing again.
                    <br>
                    The last phase of the gauntet everyone in the team will be teleported into the gauntet and everyone must run it. 3 orbs will spawn at every gate. For this to work 3 people will grab the first 3 and skip the next 3 while the other 3 grab them from the second gate. 4 people have to get out and dunk into the middle to complete this phase. once done a chest will spawn and you must go back onto the elevator and head back to the hub area to play capture the flag again.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Gauntlet Step 6.jpg" alt="" />
            </div>
        </div>
        <br>
        <div class="row">
            <div class = "col-md-12">
                <h3 class=SiteSubHeading>Boss</h3>
            </div>
        </div>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    When you first enter the room you will find the the sitting down to start the encounter you just have to shoot him. When you first start have 3 people on either side the the room and fight mobs. After a while the boss will clap and everyone will be sent to another area.
                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Boss Step 1.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    When inside 3 people must leave and 3 must stay. You can leave by running and getting an orb just a head of you will you arrive in the new area. When you are outside you will have to stay alive by killing mobs. The players inside should be calling out symbols and when they do you must kill the corasponding cyon on the platform otherwise the team inside will die.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Boss Step 2.png" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    When on the inside you will be constantly being sucked in. When you see a symbol on the bosses head you must call them out. 2 symbols will be shown each player should see a different symbol make sure you call these 2 out so the others on the outside can kill them. If they fail to kill them in time all of you will die. When being sucked in you must kill the enemys that apare they will try and launch you up to be sucked in. You also must kill the cyons quickly as if you don't if will cause a wipe.
                    <br>
                    When you reach the end the head will fire out a bunch of skulls. everyone must try and kill as many as they can as the more you kill the more dammage you can do to the boss. once they stop spawning black orbs will apare and you can head outside.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Boss Step 3.png" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    This is the dammage phase. Once outside you must stand on the 4 plates to do dammage but you want to stand on one at a time and rotate to another. When ready everyone jump onto one plate and shoot the boss. When you see the boss going to attack the plate you must leave and jump to another. If you fail to get off you fill die. You do this on each of the four plates to do dammage. 
                    <br>
                    You repeat this process until you kill the boss and get you loot. To find you rewards you godown the elevator in the middle of the room and follow the path way.
                    <br>
                    <br>
                    Contradulations you have completed the raid.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/RaidTutorialImages/Boss Step 4.jpg" alt="" />
            </div>
        </div>
        <br>
    
        <!--Comment Section-->
        <div class="row">
            <div class="col-md-12">
    <!--If user is not loged in then they will be unable to see the comment section-->
                <?php            
    if($_SESSION['UserName'] == null)
    {
    ?>
           <h4 class="SiteSubHeading">You Must Login To See Comments</h4>     
    <?php           
                
    }
    else
    {
       require_once("View/SubViews/SubmitCommentView.php");     
    }
    ?>

            </div>
        </div>
        <!--Footer-->
        <div class="row">
            <div class="col-md-12 FooterBackground">
                <br>
                <br>
                <br>
                <br>
            </div>
        </div>
    </div>



</body>

</html>
