<!--Strike Tutorial2 Page-->
<html>

<head>
    <!--Title of Website-->
    <title>
        <?=$this->title?>
    </title>
    <!--Calls CSS style Sheets-->
    <?php

                                require_once("View/SubViews/StyleSheetsView.php")

                          ?>

</head>
<!--Sets Back Ground Image-->

<body class="BackGroundImage" background="Images/Website Background.jpg">




    <div class="container-fluid">

        <!--Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h1 class="SiteHeading">
                    <?=$this->title?>
                </h1>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Navigation Section-->
        <div class="row">
            <!--Calls Navigation Bar from another View-->
            <div class="col-md-12">
                <?php

                                        require_once("View/SubViews/NavView.php")

                                        ?>
            </div>
        </div>
        <!--Secondary Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h2 class=SiteSubHeading>
                    Arms Dealer Strike tutorial
                </h2>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    When you first spawn in follow the path and kill all the enemys you find. Once that is done you will need to use your ghoat on a terminal to be able to unlock the door to the next area.
                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/ArmsDealerStrikeImages/Part 1.png" alt="" />
            </div>
        </div>
        <br>
        <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    In this next area you are tasked with just killing everything. You must keep killing enemys until you are able to colect the fuel cell from behind a tank. This tank will only move once enough enemys are killed. Once you can pick up the fuel cell grab it and fun to the way point.




                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/ArmsDealerStrikeImages/Part 2.jpg" alt="" />
            </div>" alt="" />
            </div>
        </div>
        <br>
    <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Carry this fuel cell to an area where you will have to dunk it to bring down a force field. Once it has been brought down kill all the enemys in the general area to be able to continue to the next area.
                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/ArmsDealerStrikeImages/Part 3.png" alt="" />
            </div>
            
        </div>
        <br>
    <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Traveling to the next area will take a while so I suggest that you use you sparrow until you reach it. follow the way poiny until you reach a big room with a tank. You are able to ignore this tankif you want and go to the left and head up. Kill any enemys you can and hit a leaver at the top. This willbring an elevator down that will have a tank and 2 other enemys on it. You must kill the tank to continue forward. Once this has been done the door will open and you can follow the pathway to the next area.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/ArmsDealerStrikeImages/Part 4.jpg" alt="" />
            </div>
        </div>
        <br>
    <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    When in the next area you will have your first encounter with the boss. You cannot kill him here so just ignore him and kill the other enemys you can see and make your way down the hallway. Once at the end you can flip a leave whitch will raise a elevator up to the boss arena.

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/ArmsDealerStrikeImages/Part 5.jpg" alt="" />
            </div>
        </div>
        <br>
    <!--Tutorial Information Section-->
        <div class="row">
            <div class="col-md-6">
                <p class="pContent">

                    Once in the boss area you can now do dammage to the boss. Make sure to keep other enemys under control as they can overwelm you. During this fight there will be 2 times where the boss will run away and hide under a force field. When this happens one person must run and grab a fuel cell that will apare and dunk it into an area marked with a way point to drop this force field to be able to continue dammage on the boss. Once you have done this 2 times all these is left to do is finish him off. Once he is down a chest will spawn near the front of the arena and give you your loot.
                    <br>
                    <br>
                    Contradulations you have completed the strike

                </p>
            </div>
            <!--Tutorial Image-->
            <div class="col-md-6">
                <img class="TempImage" src="Images/ArmsDealerStrikeImages/Part 6.jpg" alt="" />
            </div>
        </div>
        <br>
        <!--Comment Section-->
        <div class="row">
        <!--If user is not loged in then they will be unable to see the comment section-->
            <div class="col-md-12">
                
    <?php            
    if($_SESSION['UserName'] == null)
    {
    ?>
           <h4 class="SiteSubHeading">You Must Login To See Comments</h4>     
    <?php           
                
    }
    else
    {
       require_once("View/SubViews/SubmitCommentView.php");     
    }
    ?>

                                
        
            </div>
        </div>
        <!--Footer-->
        <div class="row">
            <div class="col-md-12 FooterBackground">
                <br>
                <br>
                <br>
                <br>
            </div>
        </div>
    



</body>

</html>
