<!--Home Page Of Website-->
<html>

<head>
    <!--Title of Website-->
    <title>
        <?=$this->title?>
    </title>
    <!--Calls CSS style Sheets-->
    <?php

                                require_once("View/SubViews/StyleSheetsView.php");
    //When page is loaded all page IDs are put into session varibles to be used to update databse when user navigates though the website.
        $_SESSION["HomePageCode"] = 1;
        $_SESSION["TutorialPageCode"] = 2;
        $_SESSION["ContactUsPageCode"] = 3;
        $_SESSION["PostTutorialPageCode"] = 4;
        $_SESSION["LoginPageCode"] = 5;
        $_SESSION["StrikesPageCode"] = 7 ;
        $_SESSION["RaidsPageCode"] = 8;
        $_SESSION["CompPageCode"] = 6;
        $_SESSION["Strike1PageCode"] = 9;
        $_SESSION["Strike2PageCode"] = 10;
        $_SESSION["Raid1PageCode"] = 11;
        
     

                          ?>
    
    
    

</head>
<!--Sets Back Ground Image-->

<body class="BackGroundImage" background="Images/Website Background.jpg">
    

    <div class="container-fluid">

        <!-- Heading Section -->

        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h1 class="SiteHeading">
                    <?=$this->title?>
                </h1>
            </div>
            <div class="col-md-3">
                <?php
    //Button used to load last page user was on before they closed the browser.
    //Will only apare if a user is loged in.
                if($_SESSION['UserName'] == null)
                {
                    
                }
                else
                {
                ?>
                <form action="./?ctr=ContinueController" method="post">
                    <div class="button">
                            <button type="submit" name="command">Continue Where You Left Off</button>
                    </div>
                </form>
                <?php
                }
                
                ?>
                
            </div>
        </div>
        <!-- Navigation Section -->

        <div class="row ">
            <!--Calls Navigation Bar from another View-->
            <div class="col-md-12">
                <?php

                                        require_once("View/SubViews/NavView.php")

                                        ?>
            </div>
        </div>
        <!--Div used for animation of an image-->
        <div class = "row">
                       
            <div class = "AnimatedImage" id = "animate">
                <img src = "Images/click_arrow.png">
            </div>

        </div>
                
        
        <!-- Carousel Section -->

        <div class="row">
            <div class="col-md-12 mypaddingfix">
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <a href="?ctr=ImageNavController&cmd=Comp"><img class="d-block w-100" src="Images/CompImage.jpg" alt="First slide"></a>
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="Images/FrontPageGamePlay.jpeg" alt="Second slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="Images/FrontPage1.jpg" alt="Third slide">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
        <br>
        <!-- Image Links Section -->
        <div class="row">
            <!--Link Takes User To Strike Tutorial Page-->
            <div class="col-md-6">
                <a href="?ctr=ImageNavController&cmd=Strikes"><img class="TempImage" src="Images/Strikes.png" alt="" />
                </a>
            </div>
            <!--Link Takes User To Raid Tutorial Page-->
            <div class="col-md-6 ">
                <a href="?ctr=ImageNavController&cmd=Raids"><img class="TempImage" src="Images/Raids.jpg" alt="" />
                </a>
            </div>
        </div>
        <br>
        <!-- Text Change Section -->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <div id="VideoInfo"> 
                <?php
    
    
    
    
    ?>
                </div>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!-- YouTube Video Section -->

        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/pXcLRnlXxz0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!-- Tutorial Links Section -->
        <div class="row">
            <div class="col-md-3">
            </div>
            <!--Links To Take User To Each Individual Tutorial-->
            <div class="col-md-6">
                <p class="TutorialLinks">
                    <a href="?ctr=TextNavController&cmd=Strike">The Inverted Spire Strike Guide</a>
                    <br>
                    <br>
                    <br>
                    <a href="?ctr=TextNavController&cmd=Strike2">The Arms Dealer Strike Guide</a>
                    <br>
                    <br>
                    <br>
                    <a href="?ctr=TextNavController&cmd=Raid">Lethiathan Raid Guide</a>

                </p>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <div class="row">
            <!-- Footer Section -->
            <div class="col-md-12 FooterBackground mypaddingfix">
                <br>
                <br>
                <br>
                <br>
            </div>
        </div>
    </div>


<!--Scripts used for this page-->
<script src = "javascript/jquery-3.3.1.min.js"></script>  
<script src = "javascript/jquery.js"></script>
<script type="text/javascript" src="javascript/compscript.js"></script>
</body>


</html>