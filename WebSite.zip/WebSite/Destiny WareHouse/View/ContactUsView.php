<!--Form For Sending Email To Admins-->
<html>

<head>
    <!--Title of Website-->
    <title>
        <?=$this->title?>
    </title>
    <!--Calls CSS style Sheets-->
    <?php

                                require_once("View/SubViews/StyleSheetsView.php")

                          ?>

</head>
<!--Sets Back Ground Image-->

<body class="BackGroundImage" background="Images/Website Background.jpg">


    <div class="container-fluid">
        <!--Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h1 class="SiteHeading">
                    <?=$this->title?>
                </h1>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Navigation Section-->
        <div class="row">
            <!--Calls Navigation Bar from another View-->
            <div class="col-md-12">
                <?php

                                        require_once("View/SubViews/NavView.php")

                                        ?>
            </div>
        </div>
        <!--Secondary Heading Section-->
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <h2 class="SiteSubHeading">
                    Contact US
                </h2>
            </div>
            <div class="col-md-3">
            </div>
        </div>
        <!--Contact Us From Section-->
        <div class="row">
            <div class="col-md-12 ContactForm">
                <form id="contact" action="Controller/ContactUsController.php" method="POST" enctype="multipart/form-data">
                    <input name="action" value="submit" type="hidden"> Your name:<br>
                    <input name="name" size="30" type="text"><br> Your email:<br>
                    <input name="email" size="30" type="text"><br> Your message:<br>
                    <textarea name="message" rows="7" cols="30">















			    </textarea><br><br>
                    <input value="Send email" type="submit">
                </form>

            </div>
        </div>
        <!--Footer-->
        <div class="row">
            <div class="col-md-12 FooterBackground">
                <br>
                <br>
                <br>
                <br>
            </div>
        </div>
    </div>




</body>

</html>
