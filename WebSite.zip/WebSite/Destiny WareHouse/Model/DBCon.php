<?php
    
    class DBconnection 
    {
        private $rs; // Procedural "handle" or "resource" to database
        private $connectRs;
        private $fetchResult;
        private $DBi;
        
//Creates A connection to the database
            private function connectDb($pStrDatabase)
            {
                $this->connectRs = mysqli_connect("localhost","root","");
                
                    if(!$this->connectRs)
                    {
                        echo "Error connecting to the database server".mysqli_error($this->connectRs);
                        $this->connectRs = -1;
                    }

                    $dbRs = mysqli_select_db($this->connectRs,$pStrDatabase);
                    if(! $dbRs)
                    {
                        echo "Error selecting the database".mysql_error($this->connectRs);

                    }

            }

//code that send the query to the database
            public function query($pStrSQL)
            {

                $this->rs = -1;// BAD RECORDSET

                $this->rs = mysqli_query($this->connectRs,$pStrSQL);
                
                    if( !$this->rs)
                    {
                        echo "Error running query [$pStrSQL] ".mysqli_error($this->connectRs)."<br>";
                        $this->rs = -1;

                    }

            }
//Example code from Todd...Not used
            public function lastCount()
            {
                $result = mysqli_num_rows($this->rs);
                return $result;
            }
//Code that runs when new DBCon is created
            public function __construct($pStrDatabase)
            {
                $this->connectDb($pStrDatabase);
            }
//Not entirly sure how this works but this code is whats gets the row from the query I think
            public function next()
            {
                $aRow = mysqli_fetch_assoc($this->rs);
                return $aRow;
            }
//Example code from Todd...Not Used
            public function free()
            {
                mysqli_free_result($this->rs);
            }
//Code that checks varibles for SQL code
            public function sqlescape($prString)
            {
                mysqli_real_escape_string ( $this->connectRs ,$prString );
                return $prString;
            }
    }
 ?>