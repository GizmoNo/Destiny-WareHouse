<?php
//Stops Error reporting
    error_reporting(E_ALL & ~E_NOTICE);
//starts new session
        session_start();

    require_once("Model/DBCon.php");
    
    
    //class gets and updates user information.
    class UpdateOrGetDataModel
    {
        public $aDA = null;
        
//Runs when new compModel is created
            public function __construct()
            {
                $this->aDA = new DBConnection('destinywarehouse');
            }
        //Updates user information with current page that they are on
        public function UpdateUser($prUname,$prPageCode)
        {
            
            $SQL = "Call UpdateUser('$prUname','$prPageCode')";
                
            $this->aDA->query($SQL);
        
                         
            
        }
        //Gets all information about a user from database.
        public function GetUser($prUname)
        {
            
            $SQL = "Call GetAllUserInfo('$prUname')";
                
            $this->aDA->query($SQL);
            
            $userInfo = $this->aDA->next();
            
            return $userInfo;
        
                         
            
        }
        
        
    

    }
            
 ?>