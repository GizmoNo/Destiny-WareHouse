<?php
//Stops Error reporting
    error_reporting(E_ALL & ~E_NOTICE);
//starts new session
        session_start();

    require_once("Model/DBCon.php");
    
    
    
    class LoginModel
    {
        public $aDB = null;
        
//Runs when new compModel is created
            public function __construct()
            {
                $this->aDA = new DBConnection('destinywarehouse');
                $this->aDB = new DBConnection('destinywarehouse');
            }
        
        //Function to register users
        public function registerUser($prUname,$prPword)
        {
            //Checks to see if user already exists
            $SQL = "Call CheckUserExists('$prUname')";
                
                $this->aDA->query($SQL);
            
                $Result = $this->aDA->next();
            //if result is null user will be inserted into the datbase.
            if($Result == null)
            {
                $SQL = "Call RegisterUser('$prUname','$prPword')";
                        
                $this->aDB->query($SQL);
            
                $row = $this->aDB->next();
                                            
                return $row;
               
            }
            //else returns null whitch will then display error message.
            else
            {
                return null;
            }
            
            
            
            
            
        }
        //function to login
        public function Login($prUname,$prPword)
        {
            //calls stored procedure and returns the row
            $SQL = "Call Login('$prUname','$prPword')";
            
            $this->aDB->query($SQL);
            
            $row = $this->aDB->next();
            
            return $row;
            
            
        }
    

    }
            
 ?>