<?php
//Stops Error reporting
    error_reporting(E_ALL & ~E_NOTICE);
//starts new session
        session_start();

    require_once("Model/DBCon.php");
    
    
    
    class CompModel
    {
        
        public $aDB = null;
        
            //Runs when new compModel is created
            public function __construct()
            {
                $this->aDB = new DBConnection('destinywarehouse');
            }
        //Inserts Competition  entry information
        public function compinfo(                           $prclsName,$prschName,$prpupEmail,$prpupPhone,$prquestionID,$pranswerID)
        {
            //Sending varibles to be checked for SQL code before it is sent to database
            $clsName =  $this->aDB->sqlescape($prclsName);
            $schName =  $this->aDB->sqlescape($prschName);
            $pupEmail =  $this->aDB->sqlescape($prpupEmail);
            $pupPhone =  $this->aDB->sqlescape($prpupPhone);
            $questionID =  $this->aDB->sqlescape($prquestionID);
            $answerID =  $this->aDB->sqlescape($pranswerID);
            
                    
            
                //Sends data to stored procedure               
                $SQL = "Call CompInsert
                        ('$clsName','$schName','$pupEmail','$pupPhone','$questionID','$answerID')"; 
                
                    //sends query to database
                    $this->aDB->query($SQL);
            
            //putting email in global varible to be used in getUserCompInfo
            $_SESSION['userEmail'] = $pupEmail;
                
                                     
                   
        }
       
        //Gets users comp entry using email varible saved in global varible
        public function getUserCompInfo($prEmail)
        {
            //Sending varibles to be checked for SQL code before it is sent to database
            $Email =  $this->aDB->sqlescape($prEmail);
            //Sends data to stored procedure 
            $SQL = "Call GetUserCompInfo ('$Email')"; 
                //sends query to database
                $this->aDB->query($SQL);
                    //Puts the row of information into varible to be returned
                    $userCompInfo = $this->aDB->next();
            
            return $userCompInfo;
        }
        
        
        
        //Gets question and answer user chose from database using questionID and answerID
        public function getUserCompAnswer($prQuestionID,$prAnswerID)
        {
            //Sending varibles to be checked for SQL code before it is sent to database
            $QuestionID =  $this->aDB->sqlescape($prQuestionID);
            $AnswerID =  $this->aDB->sqlescape($prAnswerID);
            //Sends data to stored procedure 
            $SQL = "Call GetUserQuestionAnswer ('$QuestionID','$AnswerID')"; 
                //sends query to database
                $this->aDB->query($SQL);
                    //Puts the row of information into varible to be returned
                    $userCompAnswer = $this->aDB->next();
            
            return $userCompAnswer;
            
        }
        
        
        
        
        //When multible rows are sent back this function selects the next row when asked
        public function nextAnswer()
        {
           
            return $this->aDB->next();
            
        }
        
        
        
        //Gets random question from database to be used in compView
        public function getQuestion()
        {
            //Calls stored procedure                   
            $SQL = "Call RandomQuestion()";
                //sends query to database
                $this->aDB->query($SQL);
                    //Puts the row of information into varible to be returned
                    $row = $this->aDB->next();
                
            return $row;
           
         }
        //Checks to see if school exists and returns result
        public function CheckSchool($prSchoolName)
        {
            $SchoolName =  $this->aDB->sqlescape($prSchoolName);
            //Calls stored procedure 
            $SQL = "Call GetSchool
                        ('$SchoolName')";
            //sends query to database 
            $this->aDB->query($SQL);
            //Puts the row of information into varible to be returned
            $School = $this->aDB->next();
            //Returns result
            return $School;
        }
    

    }
            
 ?>
 