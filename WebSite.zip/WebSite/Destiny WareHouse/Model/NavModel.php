<!--Controller from example code is used with all other navigation controllers-->
<?php
    
// This keeps track of the current View for controllers that dont know it
class NavModel
{
    public $currentView = "HomeView.php"; // DefaultView
    
    
    
    private function getCurrentView(){
    
        
         $lcResult = $this->currentView ;
        
         if(isset($_SESSION["view"])){
             $lcResult = $_SESSION["view"];
             
         }
        return $lcResult;
    }
    
    public function saveCurrentView($pViewName){
        // saves the current $pViewName in to SESSION
        $_SESSION["view"] = $pViewName;
        
        // updates currentView to match
        $this->currentView =  $pViewName;
        
    }
    
    function __construct(){
        $this->currentView = $this->getCurrentView();
    }
}



?>
