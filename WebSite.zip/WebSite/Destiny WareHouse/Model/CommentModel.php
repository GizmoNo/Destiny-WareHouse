<?php
/*
*  This class is used to store and retrieve information to and from a Message 
*  and show it
*/
require_once("Model/DBCon.php");

class CommentModel{
    private $Message;
    private $Name;
    private $db;
    
    public function __construct(){
        //New database contection
          $this->db = new DBconnection("destinywarehouse");
          //Sets request to a varible and then unsets it to be used again.
          if( isset($_REQUEST['name'])){
            $this->Name = $_REQUEST['name'];  
            unset($_REQUEST['name']); // Consume this REQUEST
          }
        //Sets request to a varible and then unsets it to be used again.
          if( isset($_REQUEST['message'])){
            $this->Message = $_REQUEST['message'];
            unset($_REQUEST['message']);// Consume this REQUEST
          }
        //Sets request to a varible and then unsets it to be used again.
        if( isset($_REQUEST['tutorial'])){
            $this->Tutorial = $_REQUEST['tutorial'];  
            unset($_REQUEST['tutorial']); // Consume this REQUEST
          }
         //Inserts data into database using stored procedure.
          if(isset($this->Message) && isset($this->Name)){
              
              $InsertMessageSQL = "Call InsertComment('$this->Name','$this->Message',$this->Tutorial )";
              $this->db->query($InsertMessageSQL);
           
              
          }
    }
    //Grabs all the comments for the tutorial. Only grabs the comments for the 1 tutorial
    public function SetUpMessages($prTutorial){
              $SelectMessageSQL = "Call GrabAllComments('$prTutorial')";
              $this->db->query($SelectMessageSQL);
    }
    
    public function NextMessage(){
              return $this->db->next();
    }
    
    public function FreeMessages(){
        $this->db->free();
    }
    
    
    
}


?>