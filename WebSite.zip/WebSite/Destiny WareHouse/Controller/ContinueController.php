<?php

require_once("Model/UpdateOrGetDataModel.php");
//Controller that handles the opening of the last page user was on before they closed there browser            
class ContinueController 
{
    
    public function __construct()
    {
        
        
//Gets Command from form in comp view
        if( isset($_REQUEST['command']))
        {
           
            $this->title ="Destiny WareHouse";
            
            $aModel = new UpdateOrGetDataModel();
            //Gets User from database
            $User = $aModel->GetUser($_SESSION['UserName']);
            //Grabs the page location out of the result
            $PageCode = $User['CurrentPageLocation'];
            
            
           
                
                switch($PageCode)
                {
                    //Depending on what page the user was on the correct page will load acordingly.
                    case"1":
                        require_once("View/HomeView.php");
                        break;
                        
                    case"2":
                        echo"In case";
                        require_once("View/TutorialView.php");
                        break;
                        
                    case"3":
                        require_once("View/ContactUsView.php");
                        break;
                        
                    case"4":
                        require_once("View/PostTutorialView.php");
                        break;
                        
                    case"5":
                        require_once("View/LoginView.php");
                        break;
                        
                    case"6":
                        require_once("View/CompView.php");
                        break;
                        
                    case"7":
                        require_once("View/StrikeView.php");
                        break;
                        
                    case"8":
                        require_once("View/RaidView.php");
                        break;
                        
                    case"9":
                        require_once("View/Tutorials//StrikeTutorialView.php");
                        break;
                        
                    case"10":
                        require_once("View/Tutorials//StrikeTutorialView2.php");
                        break;
                        
                    case"11":
                        require_once("View/Tutorials//RaidTutorialView.php");
                        break;
                }

            
        }
             
             
}
}


        $sMController = new ContinueController();
    
             

?>