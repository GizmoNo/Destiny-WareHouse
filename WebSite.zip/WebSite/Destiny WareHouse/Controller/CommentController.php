<?php
require_once("Model/CommentModel.php");

//Controller that handles the comment section.
class CommentController{
    
    
    public function __construct(){
        $lcView = "CommentView.php";
        
        if( isset($_REQUEST['cmd'])){
            switch($_REQUEST['cmd']){
                //When a comment has been submited requires comment view again so it updates.
                case 'Submit':
                    $lcView = "CommentView.php";
                break;
                default: 
                    $lcView = "CommentView.php";
            }
               
        }  
           
        require_once("View/SubViews//".$lcView);
           
    }
    
}

$ctrl = new CommentController();


?>