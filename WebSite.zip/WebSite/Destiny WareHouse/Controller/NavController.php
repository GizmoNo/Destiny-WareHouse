<!--Controller For Navigation Bar-->
<?php
require_once "Model/NavModel.php";
require_once("Model/UpdateOrGetDataModel.php");

class NavController
{
    
     
    
    
    /*Title Set for the website*/
    private $title = "Destiny WareHouse";
    
    
    
    
    
    
    function __construct()
    {
    
        
        /*Instantiating A New Nav Model*/
        $this->navModel = new NavModel();
        $aModel = new UpdateOrGetDataModel();
        $lcView = null;
        /*Puts the Title NavModel and Curretent View Into Varible*/
        $lcView = $this->navModel->currentView;
            
        /* When A request is made what cmd looks for the right case and setsthe title and sets the view*/
        if(isset($_REQUEST["cmd"]))
        {
            
        
            switch($_REQUEST["cmd"])
            {

                case "Home": 
                     $lcView = "HomeView.php";
                    //If user clicks link updates current page in database
                     $aModel->UpdateUser($_SESSION['UserName'],$_SESSION["HomePageCode"]);
                     break;
                case "Tutorials":
                     $this->title ="Destiny WareHouse";
                     $lcView = "TutorialView.php";
                    //If user clicks link updates current page in database
                    $aModel->UpdateUser($_SESSION['UserName'],$_SESSION["TutorialPageCode"]);
                    break;
                case "ContactUs":
                     $this->title ="Destiny WareHouse";
                     $lcView = "ContactUsView.php";
                    //If user clicks link updates current page in database
                    $aModel->UpdateUser($_SESSION['UserName'],$_SESSION["ContactUsPageCode"]);
                    break;
                case "Post Tutorial":
                     $this->title ="Destiny WareHouse";
                     $lcView = "PostTutorialView.php";
                    //If user clicks link updates current page in database
                    $aModel->UpdateUser($_SESSION['UserName'],$_SESSION["PostTutorialPageCode"]);
                    break;
                case "Login":
                     $this->title ="Destiny WareHouse";
                     $lcView = "LoginView.php";
                    //If user clicks link updates current page in database
                    $aModel->UpdateUser($_SESSION['UserName'],$_SESSION["LoginPageCode"]);
                    break;
                    //If user logs out session varible will be made to = null and will be returned to the home page
                case "LogOut":
                    $this->title ="Destiny WareHouse";
                    $_SESSION['UserName'] = null;
                    $lcView = "HomeView.php";
                    
                

                  /*If cmd = nothing then default to home page*/
                    break;
                default: 
                     $lcView = "HomeView.php";
            }
        
        // up date the saved view with the local copy
        $this->navModel->saveCurrentView($lcView);
        
        /*Finds the View in the sub folder*/
            require_once("View//".$lcView);
        }
        else
        {
            $lcView = "HomeView.php";
            require_once("View//".$lcView);
        }
    }
    
}

/*Instantiating A New Nav Controller*/
$NavController = new NavController();
?>
