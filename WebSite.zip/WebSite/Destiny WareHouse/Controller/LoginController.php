<?php

require_once("Model/LoginModel.php");
             
class LoginController 
{
    
    public function __construct()
    {
        
        //Gets Command from form in comp view
        if( isset($_REQUEST['command']))
        {
            
                switch($_REQUEST['command'])
                {
                    //If value = this run the statement      
                    case "Register":
                        
                        $this->title ="Destiny WareHouse";
                        // Making sure request contains classrooname if it does it should have the rest
                        if(isset($_REQUEST['uname']))
                        {
                            //Creates new compmodels
                            $aModel = new LoginModel();
                                                    
                    
                                                          
                            $Result = $aModel->registerUser($_REQUEST['uname'],$_REQUEST['psw']);
                            
                            if($Result == null)
                            {
                                $_SESSION["True"] = "1";
                                require_once("View/LoginView.php");
                               
                            }
                            else
                            {
                                $_SESSION['UserName'] = $Result["UserName"];
                                require_once("View/HomeView.php");
                            }
                                
                                
                                        
                            
                        
                                
                        }
                        break;
                        
                        case "Login": 
                        {
                            $this->title ="Destiny WareHouse";
                            // Making sure request contains classrooname if it does it should have the rest
                        if(isset($_REQUEST['uname']))
                        {
                            //Creates new compmodels
                            $aModel = new LoginModel();
                                                    
                    
                                                          
                            $Result = $aModel->Login($_REQUEST['uname'],$_REQUEST['psw']);
                            
                            if($Result == null)
                            {
                                $_SESSION["True"] = "2";
                                require_once("View/LoginView.php");
                               
                            }
                            else
                            {
                                $_SESSION['UserName'] = $Result["UserName"];
                                require_once("View/HomeView.php");
                            }
                        }
                        break;
                    
                               
            }
        }
    

        
            
    }
             
             
}


}
// Creates a new comp controller code normally gets skipped until the new controller is made.
        $sMController = new LoginController();
    
             

?>