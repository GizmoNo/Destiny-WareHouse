<!--Controller to Controll Navigation for Image Links-->
<?php
require_once "Model/NavModel.php";
require_once("Model/UpdateOrGetDataModel.php");

class ImageNavController
{
    
    
    /*Title Of My Website*/
    private $title = "Destiny WareHouse";
    
    
        
    public $tutorialModel;
    
    function __construct(){
        
        /*Instantiating A New Nav Model*/
        
        $this->navModel = new NavModel();
        $aModel = new UpdateOrGetDataModel();
        
        /*Puts the Title NavModel and Curretent View Into Varible*/
        
        $lcView = $this->navModel->currentView;
            
       /* When A request is made what cmd looks for the right case and setsthe title and sets the view*/
        if(isset($_REQUEST["cmd"]))
        switch($_REQUEST["cmd"]){
            case "Strikes":
                 $this->title ="Destiny WareHouse";
                 $lcView = "StrikeView.php";
                //If user clicks link updates current page in database
                $aModel->UpdateUser($_SESSION['UserName'],$_SESSION["StrikesPageCode"]);
                break;
            case "Raids":
                 $this->title ="Destiny WareHouse";
                 $lcView = "RaidView.php";
                //If user clicks link updates current page in database
                $aModel->UpdateUser($_SESSION['UserName'],$_SESSION["RaidsPageCode"]);
                break;
            case "Comp":
                $this->title ="Destiny WareHouse";
                $lcView = "CompView.php";
                //If user clicks link updates current page in database
                $aModel->UpdateUser($_SESSION['UserName'],$_SESSION["CompPageCode"]);
                break;
            
                                     
              /*If cmd = nothing then default to home page*/
                
                break;
            default: 
                 $lcView = "HomeView.php";
        }
        
        // up date the saved view with the local copy
        $this->navModel->saveCurrentView($lcView);
        
        /*Finds the View in the sub folder*/
        require_once("View//".$lcView);
    }
    
}

/*Instantiating A New Image Controller*/
$ImageNavController = new ImageNavController();
?>
