<?php

require_once("Model/CompModel.php");
             
class CompController 
{
    
    public function __construct()
    {
        
        //Gets Command from form in comp view
        if( isset($_REQUEST['command']))
        {
            
                switch($_REQUEST['command'])
                {
                    //If value = this run the statement      
                    case "CompSubmission":
                        
                        $this->title ="Destiny WareHouse";
                        // Making sure request contains classrooname if it does it should have the rest
                        if(isset($_REQUEST['classroom_name']))
                        {
                            //Creates new compmodels
                            $aModel = new CompModel();
                            $bModel = new CompModel();
                            $schoolName = $_REQUEST['school_name'];
                    //Checks if schools is real
                    $Result = $aModel->CheckSchool($schoolName);
                                
                            //If school is null will set varible to true and brings up compview instead of submit view                           
                            if($Result == null)
                            {
                                $_SESSION["True"] = "1";
                                require_once("View/CompView.php");
                                

                            }
                            // If school is real the comp submission will be submitted
                            else
                            {
                                $bModel->compinfo($_REQUEST['classroom_name'],$_REQUEST['school_name'],$_REQUEST['pupil_email'],$_REQUEST['pupil_phone'],$_REQUEST['question_ID'],$_REQUEST['question']);
                                
                                // When submitted Loadspage to another View
                                
                                require_once("View/CompSubmittedView.php");
                                        
                            }
                            
                                
                        }
                        break;
                               
            }
        }
    

            
    }
             
             
}

    // Creates a new comp controller code normally gets skipped until the new controller is made.
        $sMController = new CompController();
    
             

?>