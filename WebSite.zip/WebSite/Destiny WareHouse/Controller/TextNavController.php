<!--Controller for Text Link Navigation-->
<?php
require_once "Model/NavModel.php";
require_once "Model/UpdateOrGetDataModel.php";


class TextNavController
{
    
    
    /*Title Set for the website*/
    private $title = "Destiny WareHouse";
    
    
    
    
    public $tutorialModel;
    
    function __construct(){
        
        /*Instantiating A New Nav Model*/
        $this->navModel = new NavModel();
        $aModel = new UpdateOrGetDataModel();
        
        /*Puts the Title NavModel and Curretent View Into Varible*/
        $lcView = $this->navModel->currentView;
            
        /* When A request is made what cmd looks for the right case and setsthe title and sets the view*/
        if(isset($_REQUEST["cmd"]))
        switch($_REQUEST["cmd"]){
            case "Strike":
                 $this->title ="Destiny WareHouse";
                 $lcView = "StrikeTutorialView.php";
                //If user clicks link updates current page in database
                $aModel->UpdateUser($_SESSION['UserName'],$_SESSION["Strike1PageCode"]);
                //Varible used to identify each comment section so each tutorial has there own comments
                $_SESSION["TutorialPage"] = $_SESSION["Strike1PageCode"];
                break;
            case "Raid":
                 $this->title ="Destiny WareHouse";
                 $lcView = "RaidTutorialView.php";
                //If user clicks link updates current page in database
                $aModel->UpdateUser($_SESSION['UserName'],$_SESSION["Raid1PageCode"]);
                //Varible used to identify each comment section so each tutorial has there own comments
                $_SESSION["TutorialPage"] = $_SESSION["Raid1PageCode"];
                break;
            case "Strike2":
                $this->title ="Destiny WareHouse";
                $lcView = "StrikeTutorialView2.php";
                //If user clicks link updates current page in database
                $aModel->UpdateUser($_SESSION['UserName'],$_SESSION["Strike2PageCode"]);
                //Varible used to identify each comment section so each tutorial has there own comments
                $_SESSION["TutorialPage"] = $_SESSION["Strike2PageCode"];
                break;
                
            
                                     
              /*If cmd = nothing then default to home page*/
                break;
            default: 
                 $lcView = "HomeView.php";
        }
        
        // up date the saved view with the local copy
        $this->navModel->saveCurrentView($lcView);
        
        /*Finds the View in the sub folder*/
        require_once("View/Tutorials//".$lcView);
    }
    
}
/*Instantiating A New TextNav Controller*/
$TextNavController = new TextNavController();
?>
