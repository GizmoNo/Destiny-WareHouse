<!--This code can send a email to a specified email address-->
<?php
$action=$_REQUEST['action'];
    /* send the submitted data */
    
    $name=$_REQUEST['name'];
    $email=$_REQUEST['email'];
    $message=$_REQUEST['message'];
    if (($name=="")||($email=="")||($message==""))
        {
        echo "All fields are required, please fill <a href='/contact.html'>the form</a> again.";
        }
    else{        
        $from="From: $name<$email>\r\nReturn-path: $email";
        $subject="Message sent using your contact form";
        mail("Email Address", $subject, $message, $from);
        echo "Email sent! <br><br>";
        echo "<a href='/contactus.html'>";
		echo "Return to site";
		echo "</a>";                }
      
?>
